class Lab4_Task1{
public static void main(String []args){
int arr[]={1,1,1,1,1};
int max=arr[0];
int Second_largest=-1;
for(int i=0;i<arr.length;i++)
{
  if(arr[i]>max)
  {
    max=arr[i];
  }
}
 for(int j=0;j<arr.length;j++)
 {
      if (arr[j]>Second_largest&&arr[j]<max)
    {
    Second_largest=arr[j];
    }
 }
System.out.println(Second_largest);
}
}